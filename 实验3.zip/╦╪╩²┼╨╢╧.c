#include <math.h>
#include <stdio.h>
int main()
{
	int number,flag,i,n;
	printf("Input n:\n");
	scanf("%d",&number);
	if (number<=1)
	{
		flag = 0;
	}
	int m = 0;
	for (int i= 2; i < n; i++ ){
		    if(n % i == 0){
		    	 m++;
			}
	}
	if(m == 0){
		   printf("%d������\n",n);
	} else {
		   printf("%d��������\n",n);
	}
}
    return 0
