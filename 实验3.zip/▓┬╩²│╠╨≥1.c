#include <stdlib.h>
#include <stdio.h>
#include <time.h>
int main()
{
	int magic;
	int guess;
	srand(time(NULL));
	magic = rand() % 100 + 1;
	printf("������һ��1--100������");
	scanf("%d",&guess);
	if (guess > magic)
	{
	   printf("wrong,toohigh\n");
	} 
	else if (guess < magic)
	{
	   printf("wrong,too low\n");
	}
	else
	{
	printf("right\n");
	printf("���־���:%d\n",magic);
	}
	return 0; 
}
