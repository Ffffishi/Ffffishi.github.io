#include <stdlib.h>
#include <stdio.h>
#include <time.h>
int main()
{
	int magic;
	int guess;
	int counter;
	char reply; 
	srand(time(NULL));
do{
		
	magic = rand() % 100 + 1;
	counter = 0;
	do{
	  printf("������һ��1--100������");
	  scanf("%d",&guess);
	  counter++;
	  if (guess > magic)
	  {
	     printf("wrong,too high\n");
      }
	  else if (guess < magic)
	  {
	     printf("wrong,too low\n");
	  }
	  else
	  {
	  	printf("right\n");
	  }
    }while (guess != magic && counter < 10);
	printf("���־���:%d\n",magic);
	printf("һ������%d��\n",counter); 
	printf("�Ƿ�Ը�����(y/n)?");
	scanf(" %c",&reply);
}while ((reply == 'Y')||(reply == 'y'));
  return 0;
}
